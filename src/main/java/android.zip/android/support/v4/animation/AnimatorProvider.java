package android.support.v4.animation;

interface AnimatorProvider {
    ValueAnimatorCompat emptyValueAnimator();
}
