package android.support.v4.widget;

interface DrawerLayoutImpl {
    void setChildInsets(Object obj, boolean z);
}
