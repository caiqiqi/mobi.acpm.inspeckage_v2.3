package android.support.v7.internal.transition;

import android.view.ViewGroup;

public class ActionBarTransition {
    private static final boolean TRANSITIONS_ENABLED = false;
    private static final int TRANSITION_DURATION = 120;

    public static void beginDelayedTransition(ViewGroup sceneRoot) {
    }
}
