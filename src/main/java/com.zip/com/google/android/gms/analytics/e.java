package com.google.android.gms.analytics;

interface e {
    void B(boolean z);
}
