package com.google.android.gms.analytics;

class aa implements m {
    String Bj;
    int Bk = -1;
    int Bl = -1;
    String ya;
    String yb;

    aa() {
    }

    public boolean eO() {
        return this.ya != null;
    }

    public String eP() {
        return this.ya;
    }

    public boolean eQ() {
        return this.yb != null;
    }

    public String eR() {
        return this.yb;
    }

    public boolean eS() {
        return this.Bj != null;
    }

    public String eT() {
        return this.Bj;
    }

    public boolean eU() {
        return this.Bk >= 0;
    }

    public int eV() {
        return this.Bk;
    }

    public boolean eW() {
        return this.Bl != -1;
    }

    public boolean eX() {
        return this.Bl == 1;
    }
}
