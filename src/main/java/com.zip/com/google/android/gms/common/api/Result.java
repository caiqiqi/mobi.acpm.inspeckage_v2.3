package com.google.android.gms.common.api;

public interface Result {
    Status getStatus();
}
