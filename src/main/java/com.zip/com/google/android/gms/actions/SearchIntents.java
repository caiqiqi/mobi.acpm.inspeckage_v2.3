package com.google.android.gms.actions;

public class SearchIntents {
    public static final String ACTION_SEARCH = "com.google.android.gms.actions.SEARCH_ACTION";

    private SearchIntents() {
    }
}
