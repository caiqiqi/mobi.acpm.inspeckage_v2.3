package com.google.android.gms.analytics;

import com.google.android.gms.internal.ha;
import java.util.List;
import java.util.Map;

interface ak {
    void b(Map<String, String> map, long j, String str, List<ha> list);

    void dQ();

    void dW();

    void dispatch();

    void eB();
}
