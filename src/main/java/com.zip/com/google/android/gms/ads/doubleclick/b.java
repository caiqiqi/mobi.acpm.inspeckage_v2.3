package com.google.android.gms.ads.doubleclick;

public interface b {
    void a(a aVar);
}
