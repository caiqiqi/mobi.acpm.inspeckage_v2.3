package com.google.android.gms.drive.events;

public interface ChangeListener extends c {
    void onChange(ChangeEvent changeEvent);
}
