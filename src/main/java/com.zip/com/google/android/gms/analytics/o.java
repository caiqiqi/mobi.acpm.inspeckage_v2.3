package com.google.android.gms.analytics;

import java.util.Set;

public interface o {
    int eb();

    int ec();

    int ed();

    int ee();

    long ef();

    String eg();

    String eh();

    i ei();

    l ej();

    Set<Integer> ek();
}
