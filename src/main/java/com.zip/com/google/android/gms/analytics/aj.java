package com.google.android.gms.analytics;

abstract class aj {
    aj() {
    }

    abstract void C(boolean z);

    abstract void dispatchLocalHits();

    abstract void ey();

    abstract void setLocalDispatchPeriod(int i);
}
