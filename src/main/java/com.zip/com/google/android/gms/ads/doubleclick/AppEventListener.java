package com.google.android.gms.ads.doubleclick;

public interface AppEventListener {
    void onAppEvent(String str, String str2);
}
