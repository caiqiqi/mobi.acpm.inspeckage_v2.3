package com.google.android.gms.ads.mediation.customevent;

public interface CustomEventInterstitialListener extends CustomEventListener {
    void onAdLoaded();
}
